﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Este es mi proyecto: Calculo de peso estructural");
        Console.WriteLine();
        Console.WriteLine("Este programa es capaz de calcular el peso de diversas estructuras de ");
        Console.WriteLine("contruccion tales como una losa, una viga y una columna");
        Console.WriteLine();
        Console.WriteLine("Presione Enter para continuar...");
        Console.ReadLine();
        //presentacion de menu principal
        bool salir = false;
        while (!salir)
        {
            Console.Clear();
            Console.WriteLine("Menú Principal:");
            Console.WriteLine("1. Proceso Principal");
            Console.WriteLine("2. Manual de Usuarios");
            Console.WriteLine("3. Créditos");
            Console.WriteLine("4. Salir");
            Console.WriteLine("Seleccione el numero de la opcion que desea realizar");

            string opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    ProcesoPrincipal();
                    break;
                case "2":
                    ManualUsuario();
                    break;
                case "3":
                    Console.WriteLine("Ud. se encuentra en los creditos");
                    Console.WriteLine("Presione Enter para volver al menú principal...");
                    Console.ReadLine();
                    break;
                case "4":
                    salir = true;
                    break;
                default:
                    Console.WriteLine("Opción inválida. Por favor, ingrese una opción válida.");
                    Console.WriteLine("Presione Enter para continuar...");
                    Console.ReadLine();
                    break;
            }
        }
    }
    //Se realizo un clase para proceso principal
    static void ProcesoPrincipal()
    {
        bool volver = false;
        while (!volver)
        {
            Console.Clear();
            Console.WriteLine("Menú de Proceso Principal:");
            Console.WriteLine("1. Cálculos de Peso de Viga");
            Console.WriteLine("2. Cálculos de Peso de Losa");
            Console.WriteLine("3. Cálculos de Peso de Columna");
            Console.WriteLine("4. Salir al Menú Principal");
            Console.WriteLine("Por el momento las opciones 1, 2 y 3 no se encuentran disponibles seleccione 4 para salir");

            string opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    Console.WriteLine("Realizando cálculos de peso de viga...");
                    // agregar logica para calculos de viga
                    Console.WriteLine("Presione Enter para volver al menú de Proceso Principal...");
                    Console.ReadLine();
                    break;
                case "2":
                    Console.WriteLine("Realizando cálculos de peso de losa...");
                    //  agregar logica para calculos de losa
                    Console.WriteLine("Presione Enter para volver al menú de Proceso Principal...");
                    Console.ReadLine();
                    break;
                case "3":
                    Console.WriteLine("Realizando cálculos de peso de columna...");
                    //  agregar logica para calculos de columna
                    Console.WriteLine("Presione Enter para volver al menú de Proceso Principal...");
                    Console.ReadLine();
                    break;
                case "4":
                    volver = true;
                    break;
                default:
                    Console.WriteLine("Opción inválida. Por favor, ingrese una opción válida.");
                    Console.WriteLine("Presione Enter para continuar...");
                    Console.ReadLine();
                    break;
            }
        }
    }
    // se realizo un clase para manual de usuario
    static void ManualUsuario()
    {
        Console.WriteLine("Este es el manual del programa.");
        Console.WriteLine("Presione Enter para volver al menú principal...");
        Console.ReadLine();
    }
}
