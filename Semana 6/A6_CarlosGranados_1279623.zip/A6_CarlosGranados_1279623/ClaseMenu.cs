﻿class claseMenu
{
    static void Main (string[] args)
   {
        Console.WriteLine("Mi programa es calculo de cargas estrucutrales para una vivienda");
        Console.WriteLine();
        Console.WriteLine("Seleccione un tipo de carga");
        Console.WriteLine("Menu principal");
        Console.WriteLine("1. Calculo de tensiones");
        Console.WriteLine("2. Calculo de carga y viento");
        Console.WriteLine("3. Calculo de esfuerzo cortante");
        Console.WriteLine("4. Calculo de movimientos sismicos");

        string seleccionMenu;

        seleccionMenu = Console.ReadLine();

        switch (seleccionMenu)
        {
            case "1":
                Console.WriteLine("Usted selecciono la opcion: " + seleccionMenu + " Calculo de tensiones");
                break;
            case "2":
                Console.WriteLine("Usted selecciono la opcion: " + seleccionMenu + " Calculo de cargas y viento");
                break;
            case "3":
                Console.WriteLine("Usted selecciono la opcion: " + seleccionMenu + " Calculo de esfuerzo cortante");
                break;
            case "4":
                Console.WriteLine("Usted selecciono la opcion: " + seleccionMenu + " Calculo de movimientos sismicos");
                break;

            default:
                Console.WriteLine("Seleccione una opcion valida");
                break;
        }
        Console.ReadKey();
    }
    static int stmetodoDummy()
    {
      
        return 1;

    }
}