﻿using System;

class Persona
{
    // Propiedades
    public string Nombre { get; set; }
    public int Edad { get; set; }
    public string Genero { get; set; }
    public string Dpi { get; set; }
    public string Facultad { get; set; }
    public string EstadoCivil { get; set; }

    // Método para solicitar nombre y mostrarlo
    public void SolicitarNombre()
    {
        Console.Write("Ingrese su nombre: ");
        Nombre = Console.ReadLine();
    }

    // Método para solicitar edad y calcular el año de nacimiento
    public void CalcularAnio()
    {
        Console.Write("Ingrese su edad: ");
        int.TryParse(Console.ReadLine(), out int edad);

        Edad = edad;
        int anioNacimiento = DateTime.Now.Year - edad;
        Console.WriteLine($"Año de nacimiento: {anioNacimiento}");
    }

    // Método para solicitar el resto de la información y mostrarla
    public void InformacionCompleta()
    {
        Console.Write("Ingrese su género: ");
        Genero = Console.ReadLine();

        Console.Write("Ingrese su DPI: ");
        Dpi = Console.ReadLine();

        Console.Write("Ingrese su facultad: ");
        Facultad = Console.ReadLine();

        Console.Write("Estado Civil (casado/soltero/divorciado): ");
        EstadoCivil = Console.ReadLine();

        Console.WriteLine($"Nombre: {Nombre}");
        Console.WriteLine($"Edad: {Edad}");
        Console.WriteLine($"Género: {Genero}");
        Console.WriteLine($"DPI: {Dpi}");
        Console.WriteLine($"Facultad: {Facultad}");
        Console.WriteLine($"Estado Civil: {EstadoCivil}");
    }
}

class Program
{
    static void Main()
    {
        // Crear una nueva instancia de la clase Persona
        Persona persona = new Persona();

        // Llamar a los métodos para solicitar y mostrar información
        persona.SolicitarNombre();
        persona.CalcularAnio();
        persona.InformacionCompleta();
    }
}