﻿using System;

class Program
{
    static void Main()
    {
        double monto;
        double descuento = 0.0;

        Console.WriteLine("Ingrese el monto de la compra en Q:");
        if (double.TryParse(Console.ReadLine(), out monto))
        {
            if (monto < 400)
            {
                // No hay descuento
            }
            else if (monto <= 1000)
            {
                descuento = 0.07; // 7% de descuento
            }
            else if (monto <= 5000)
            {
                descuento = 0.10; // 10% de descuento
            }
            else if (monto <= 15000)
            {
                descuento = 0.15; // 15% de descuento
            }
            else
            {
                descuento = 0.25; // 25% de descuento
            }

            Console.WriteLine("¿Tiene un código de descuento? (S/N)");
            string tieneDescuento = Console.ReadLine().ToUpper();
            if (tieneDescuento == "S")
            {
                descuento += 0.05; // 5% de descuento adicional
            }

            double montoFinal = monto - (monto * descuento);
            Console.WriteLine($"El monto a pagar después del descuento es: Q{montoFinal}");
        }
        else
        {
            Console.WriteLine("Error: Por favor, ingrese un monto válido.");
        }
        Console.ReadKey();
    }
}