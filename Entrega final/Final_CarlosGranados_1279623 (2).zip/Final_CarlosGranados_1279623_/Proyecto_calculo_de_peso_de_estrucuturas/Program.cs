﻿using System;

class Program
{
    static void Main()
    {
        // presentación del menu de bienvenida 
        Console.WriteLine("Este es mi proyecto: Calculo de peso estructural");
        Console.WriteLine();
        Console.WriteLine("Este programa es capaz de calcular el peso de diversas estructuras de ");
        Console.WriteLine("Construcción tales como una losa, una viga y una columna");
        Console.WriteLine();
        Console.WriteLine("Presione Enter para continuar...");
        Console.ReadLine();
        
        //presentación de menu principal

        bool salir = false;
        while (!salir)
        {
            Console.Clear();
            Console.WriteLine("-----Menú Principal-----");
            Console.WriteLine() ;
            Console.WriteLine("1. Proceso Principal");
            Console.WriteLine("2. Manual de Usuarios");
            Console.WriteLine("3. Créditos");
            Console.WriteLine("4. Salir");
            Console.WriteLine("Seleccione el numero de la opción que desea realizar");

            // selección del procedimiento que se desea realizar
            string opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    // llamado del método principal
                    ProcesoPrincipal();
                    break;
                case "2":
                    // llamado para el método de manual de usuario 
                    ManualUsuario();
                    break;
                case "3":
                    // presentación de los créditos 
                    Console.WriteLine("Calculo de peso de estructuras(vigas, columnas y losas)");
                    Console.WriteLine("Fecha de creación 21/10/2023");
                    Console.WriteLine("Estimación de horas invertidas para desarrollar el programa: 12h ");
                    Console.WriteLine("Carlos Omar Granados González");
                    Console.WriteLine("No. Carnet 1279613");
                    Console.WriteLine("Ingeniería Civil");
                    Console.WriteLine("Presione Enter para volver al menú principal...");
                    Console.ReadLine();
                    break;
                    
                
                    break;
                case "4":
                    salir = true;
                    break;
                    // si no se selecciono ninguna opción valida le solicitara ingresar una valida
                default:
                    Console.WriteLine("Opción inválida. Por favor, ingrese una opción válida.");
                    Console.WriteLine("Presione Enter para continuar...");
                    Console.ReadLine();
                    break;
            }
        }
    }
    //Se realizo un método para proceso principal
    
    static void ProcesoPrincipal()
    {
        bool volver = false;
        while (!volver)
        {
            Console.Clear();
            // se presentaron los tipos de cálculos que el programa puede realizar 
            Console.WriteLine("-----Menú de Proceso Principal-----");
            Console.WriteLine();
            Console.WriteLine("1. Cálculos de Peso de Viga");
            Console.WriteLine("2. Cálculos de Peso de Losa");
            Console.WriteLine("3. Cálculos de Peso de Columna");
            Console.WriteLine("4. Regresar al menu Principal");
            Console.WriteLine("Seleccione el número de la opción que desea realizar");

            string opcion = Console.ReadLine();

            switch (opcion)
            {
                // para la opción 1, 2 y 3 se creo un método nuevo
                case "1":
                    CalcularPesoEstructura("viga");
                    break;

                case "2":
                    CalcularPesoEstructura("losa");
                    break;
                case "3":
                    CalcularPesoEstructura("columna");
                    break;
                case "4":
                    return;
                default:
                    Console.WriteLine("Opción inválida. Por favor, ingrese una opción válida.");
                    Console.WriteLine("Presione Enter para continuar...");
                    Console.ReadLine();
                    break;
            }
        }
    }

    static void CalcularPesoEstructura(string tipoEstructura)
    {
        bool volver = false;
        Console.Clear();
        Console.WriteLine("---Cálculos de Peso de " + tipoEstructura + "---");
        Console.WriteLine();

        // Solicitar al usuario el tipo de material
        Console.WriteLine("--Seleccione el tipo de material de la estructura--");
        Console.WriteLine();
        Console.WriteLine("1. Acero");
        Console.WriteLine("2. Tradicional");
        Console.WriteLine("3. Salir al menu de proceso principal");
        string tipoMaterial = Console.ReadLine();

        double pesoMaterial = 0;

        if (tipoMaterial.ToLower() == "1")

        {

            Console.WriteLine();
            Console.WriteLine("---Seleccione el tipo de acero---");
            Console.WriteLine();
            Console.WriteLine("1. Estructural = 7850 kg/m³");
            Console.WriteLine("2. Reforzado = 8050 kg/m³");
            string tipoAcero = Console.ReadLine();

            Console.WriteLine();
            Console.WriteLine("Ingrese el volumen de la estructura en m³:");
            double volumen = Convert.ToDouble(Console.ReadLine());

            double densidadAcero = (tipoAcero == "1") ? 7850 : 8050; // kg/m^3
            double pesoEnKg = volumen * densidadAcero;
            double gravedad = 9.81; // m/s2
            double pesoEnNewton = pesoEnKg * gravedad;

            Console.WriteLine("El peso de la estructura en kilogramos: " + pesoEnKg);
            Console.WriteLine("El peso de la estructura en Newtons: " + pesoEnNewton);
        }
       
          
        else if (tipoMaterial.ToLower() == "2")
        {
            Console.WriteLine() ;
            Console.WriteLine("Ingrese el volumen de la estructura en m³");
            double volumen = double.Parse(Console.ReadLine());

            // Solicitar el tipo de concreto
            Console.WriteLine("--Seleccione el tipo de concreto--");
            Console.WriteLine("1. Tradicional =  2,200kg/m³");
            Console.WriteLine("2. Reforzado = 2,400kg/m³");
            string tipoConcreto = Console.ReadLine();

            double densidadConcreto = (tipoConcreto.ToLower() == "1") ? 2200 : 2400; //densidades del concreto en kg/m³

            // Calcular peso del concreto
            double pesoConcreto = volumen * densidadConcreto;

            // Solicitar los tipos de varillas
            string[] tiposVarillas = { "3/8", "1/2", "5/8", "3/4", "7/8", "1" };

            foreach (var tipoVarilla in tiposVarillas)
            {
                Console.WriteLine();
                Console.WriteLine("Ingrese la longitud de las varillas en metros de: " + tipoVarilla);
                double longitud = double.Parse(Console.ReadLine());

                double r = 0; // radio

                switch (tipoVarilla)
                {
                    case "3/8":
                        r = 0.009525; //metros
                        break;
                    case "1/2":
                        r = 0.0127; //metros
                        break;
                    case "5/8":
                        r = 0.015875; //metros
                        break;
                    case "3/4":
                        r = 0.01905;//metros
                        break;
                    case "7/8":
                        r = 0.022225;//metros
                        break;
                    case "1":
                        r = 0.0254;//metros 
                        break;
                }

                Console.WriteLine("Ingrese la cantidad de varillas " + tipoVarilla);
                int cantidadVarillas = int.Parse(Console.ReadLine());

                // Calcular el peso de cada tipo de varilla
                double e = 7850; // kg/m^3
                double pesoVarilla = Math.PI * Math.Pow(r, 2) * longitud * e * cantidadVarillas;

                // Sumar el peso de las varillas al peso del concreto
                pesoMaterial = pesoVarilla + pesoConcreto;
            }

            // Mostrar el resultado en kg y Newtons
            Console.WriteLine($"El peso total de la estructura es: " + pesoMaterial+ " kg");
            Console.WriteLine($"El peso total de la estructura es: " +pesoMaterial * 9.81 + "Newtons"); // 9.81 corresponde a la gravedad 
        }

        Console.WriteLine("Presione Enter para volver al menú de Proceso Principal...");
        Console.ReadLine();
    }
    // se realizo un clase para manual de usuario
    static void ManualUsuario()
    {
        Console.WriteLine("Este es el manual del programa.");
        Console.WriteLine("El programa consiste en un menu principal con las opciones de proceso principal, Manual de usuario, créditos y salir");
        Console.WriteLine("Si el usuario selecciona proceso principal le desplegara un nuevo menu donde el usuario podrá escoger la estructura que " +
            "desea determinar el peso y si presiona un enter lo devolverá al menu principal");
        Console.WriteLine("Una vez seleccionado el proceso principal le desplegara el tipo de estructura que desea realizar el calculo");
        Console.WriteLine("Tendrá como opciones el calculo para una columna, una viga y una losa ");
        Console.WriteLine("Independientemente del tipo de estructura que selecciono le desplegara si la estructura es del tipo tradicional(varillas y concreto) o de acero ");
        Console.WriteLine("Si el usuario selecciona el tipo tradicional le solicitara que ingrese el volumen de la estructura luego le pedirá que seleccione el tipo de concreto que se usara en el tipo de estructura" +
            "una vez seleccionado el tipo de concreto el programa le empezara a solicitar el tipo de varilla que se uso para la estructura si no se empleo el tipo de varilla que le pregunta el programa coloque 0 " +
            "por ultimo con todos los datos ingresados  el programa le devolverá el peso total de la estructura en kg como también en Newtons");
        Console.WriteLine("Si el usuario selecciona Manual de usuario lo dirigirá a esta sección que explica como funciona el programa y si presiona un enter lo devolverá al menu principal");
        Console.WriteLine("Si el usuario selecciona créditos le mostrara la información de creación del programa");
        Console.WriteLine("Si el usuario selecciona la opción salir el programa se dejara de ejecutar");
        Console.WriteLine();
        Console.WriteLine("Este programa fue creado con el fin que en la planeación de una construcción se debe conocer el peso de las estructuras" +
            "o estimación esto para saber si el tipo de suelo es capaz de soportar el peso o si las mismas estructuras son capaces de sostener las misma " +
            "integridad de la edificación esto se puede dar desde viviendas de dos plantas hasta un edificio");
        Console.WriteLine("Presione Enter para volver al menú principal...");
        Console.ReadLine();

    }
}
