﻿

using System.ComponentModel.Design;

namespace L7_CarlosGranados_1279623
{
    class program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 1");
            int numero1 = 0;


            Console.WriteLine("Ingrese numero");
            numero1 = Int32.Parse(Console.ReadLine());


            if (numero1 > 0)
            {
                Console.WriteLine("El numero es positivo");

            }
            else if (numero1 == 0)
            {

                Console.WriteLine("El numero es igual a cero");
            }
            else
            {
                Console.WriteLine("El numero es negativo");
            }
            Console.ReadKey();
            Console.Clear();


            // segundo problema 

            Console.WriteLine("Ejercicio 2");

            Console.WriteLine("Ingrese un numero");
            string semana;
            semana = Console.ReadLine();

            switch (semana)
            {
                case "1":
                    Console.WriteLine("El dia ingresado es lunes");
                    break;
                case "2":
                    Console.WriteLine("El dia ingresado es martes");
                    break;
                case "3":
                    Console.WriteLine("El dia ingresado es miercoles");
                    break;
                case "4":
                    Console.WriteLine("El dia ingresado es jueves");
                    break;
                case "5":
                    Console.WriteLine("El dia ingresado es viernes");
                    break;
                case "6":
                    Console.WriteLine("El dia ingresado es sabado");
                    break;
                case "8":
                    Console.WriteLine("El dia ingresado es domingo");
                    break;
                
                default:
                    Console.WriteLine("Error.El numero a ingresar debe estar contenido entre 1 y 7");
                    break;
            }
            
            Console.ReadKey();
            Console.Clear();



        }



    }

}