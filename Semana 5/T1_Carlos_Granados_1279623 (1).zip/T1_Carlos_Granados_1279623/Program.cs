﻿using System.Xml.Serialization;

class program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Mi segundo programa");
        string sNombre, sEdad, SCarrera, sCarne;
        Console.WriteLine("Ingrrese nombre");
        sNombre = Console.ReadLine();
        Console.WriteLine("Ingrese edad");
        sEdad = Console.ReadLine();
        Console.WriteLine("Ingrese carrera");
        SCarrera = Console.ReadLine();
        Console.WriteLine("Ingrese carne");
        sCarne = Console.ReadLine();


        Console.WriteLine("Nombre:  " + sNombre);
        Console.WriteLine("Edad: " + sEdad);
        Console.WriteLine("Carrera: " + SCarrera );
        Console.WriteLine("Carnet: " + sCarne);
        
        Console.WriteLine("Soy " + sNombre +" tengo " + sEdad + " años y estudio la carrera de " + SCarrera + " Mi carne es " + sCarne);
        Console.ReadKey();
    }
}

