﻿using System.Xml.Serialization;

class program
{
    static void Main(string[] args)
    {
    Console.WriteLine("Ingrese su nomnbre");
        string Nombre = Console.ReadLine();
        Console.WriteLine("Hola mundo");
        Console.WriteLine("Soy " + Nombre );
        /*
         Esto es un ejemplo de comentarios
        */
        Console.WriteLine("Hola mundo");
        Console.WriteLine("Soy " + Nombre);
        Console.ReadKey();
    }
}

