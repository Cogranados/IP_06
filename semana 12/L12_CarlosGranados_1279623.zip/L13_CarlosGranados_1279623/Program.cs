﻿using System;

class Program
{
    static void Main()
    {
        int[] numeros = new int[10];
        int sumaTotal = 0;
        int sumaPosicionesPares = 0;
        int sumaPosicionesImpares = 0;

        for (int i = 0; i < 10; i++)
        {
            Console.Write($"Ingrese el número {i + 1}: ");
            numeros[i] = Convert.ToInt32(Console.ReadLine());
            sumaTotal += numeros[i];

            if (i % 2 == 0)
            {
                sumaPosicionesPares += numeros[i];
            }
            else
            {
                sumaPosicionesImpares += numeros[i];
            }
        }

        int numeroMasPequeno = numeros[0];
        int numeroMasGrande = numeros[0];
        for (int i = 1; i < 10; i++)
        {
            if (numeros[i] < numeroMasPequeno)
            {
                numeroMasPequeno = numeros[i];
            }
            if (numeros[i] > numeroMasGrande)
            {
                numeroMasGrande = numeros[i];
            }
        }

        double promedio = (double)sumaTotal / 10;

        Console.WriteLine($"El número más pequeño ingresado es: {numeroMasPequeno}");
        Console.WriteLine($"El número más grande ingresado es: {numeroMasGrande}");
        Console.WriteLine($"La suma total de los números ingresados es: {sumaTotal}");
        Console.WriteLine($"Los números ingresados ordenados por posición son: {string.Join(", ", numeros)}");
        Array.Reverse(numeros);
        Console.WriteLine($"Los números ingresados ordenados en posición inversa son: {string.Join(", ", numeros)}");
        Console.WriteLine($"El promedio de los números ingresados es: {promedio}");
        Console.WriteLine($"La suma de posiciones pares es: {sumaPosicionesPares}");
        Console.WriteLine($"La suma de posiciones impares es: {sumaPosicionesImpares}");
    }
}
